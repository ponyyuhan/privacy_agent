# MIRAGE-OG++ (Demo Codebase)

This repository is a runnable **research demo** for **MIRAGE‑OG++**:

- **Level 2 (Myouting Opacity)**: the agent cannot call low-level tools directly (no `shell.exec`, no `http.request`, no `file.read`).  
  It can only call one gateway tool: `mirage.act(intent_id, inputs, constraints)`.

- **Level 1 (Secret Myopia)**: sensitive data is never returned to the agent. The gateway returns **sealed handles** (opaque IDs).
  Handles are **non-exportable** (bound to session + TTL in this demo).

- **Oblivious Guardrails (FSS-based)**: before any externalization (e.g., `SendMessage`), the gateway runs privacy-preserving checks
  against **remote centralized policy databases** hosted by two non-colluding policy servers.
  The guardrail queries are implemented as **2-server FSS-PIR** using a simple point-function secret sharing (large keys, easy demo).
  Each policy server sees a **random-looking key share** and learns nothing about the queried token or recipient/domain.

> ⚠️ This is a demo/prototype. It is not hardened production security code.

## Quickstart

### 1) Install deps

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Build policy DB bitsets

```bash
python policy_server/build_dbs.py
```

This creates bitset files under `policy_server/data/`.

### 3) Start two policy servers (in two terminals)

Terminal A:

```bash
SERVER_ID=0 PORT=19001 python -m policy_server.server
```

Terminal B:

```bash
SERVER_ID=1 PORT=19002 python -m policy_server.server
```

### 4) Start the gateway (Terminal C)

```bash
PORT=18000 python -m gateway.app
```

### 5) Run the demo agent (Terminal D)

Benign run:

```bash
python -m agent.nanoclaw_agent benign
```

Malicious run:

```bash
python -m agent.nanoclaw_agent malicious
```

## What you should see

- Benign: message is allowed.
- Malicious:
  1) tries to read a "private key" -> only gets a handle, never the key.
  2) tries to exfiltrate the handle -> blocked (HIGH handle cannot flow to egress).
  3) tries to exfiltrate a message containing an AWS-like token substring -> blocked by **oblivious guardrails** (FSS-PIR query).

## Architecture overview

```
agent (untrusted) -> gateway (trusted, minimal TCB) -> executors (least privilege)
                                       |
                                       +-> policy_server0 (honest-but-curious)
                                       +-> policy_server1 (honest-but-curious)
```

## Code map

- `agent/` : minimal agent + skills (benign/malicious)
- `gateway/` : MIRAGE gateway: intent router, handle store, executors, guardrails client
- `policy_server/` : policy servers hosting bitset databases and answering FSS-PIR queries
- `scripts/` : helper scripts

## Security model (demo)

- Agent + skills are **untrusted**.
- Gateway is **trusted** (small TCB).
- Two policy servers are **non-colluding**; at least one is honest.
- Network is protected by TLS in real deployments (this demo uses HTTP on localhost).

This demo focuses on:
- preventing **secret disclosure to the agent** (Level 1),
- preventing the agent from knowing low-level tool/command details (Level 2),
- enabling **centralized auditing/guardrails without revealing plaintext content or intent tokens** to any single auditor (Oblivious Guardrails via FSS-PIR).

## Notes for researchers

- The FSS construction used here is the simplest point-function sharing with O(N) key size.
  For real systems, replace it with efficient DPF/FSS libraries (e.g., Google's DPF implementation) and optimized PIR kernels.
