import base64
from pathlib import Path
from typing import Dict

def parity_bytes(b: bytes) -> int:
    # parity of bitcount
    return (int.from_bytes(b, "little").bit_count() & 1)

class BitsetDB:
    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self._db: Dict[str, bytes] = {}

    def load(self):
        for name in ["banned_tokens", "allow_recipients", "allow_domains"]:
            p = self.data_dir / f"{name}.bitset"
            if not p.exists():
                raise FileNotFoundError(f"Missing DB file: {p}")
            self._db[name] = p.read_bytes()

    def query(self, db_name: str, key_share_b64: str) -> int:
        if db_name not in self._db:
            raise KeyError(f"Unknown db: {db_name}")
        key = base64.b64decode(key_share_b64)
        db = self._db[db_name]
        if len(key) != len(db):
            raise ValueError("Key length mismatch (domain_size mismatch).")
        # ans_share = parity(key & db)   over GF(2)
        anded = bytes([a & b for a, b in zip(key, db)])
        return parity_bytes(anded)
