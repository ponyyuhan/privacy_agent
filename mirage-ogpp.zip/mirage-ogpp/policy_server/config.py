import os
from dataclasses import dataclass

@dataclass
class Settings:
    server_id: int = int(os.getenv("SERVER_ID", "0"))
    port: int = int(os.getenv("PORT", "9001"))
    data_dir: str = os.getenv("DATA_DIR", "policy_server/data")

settings = Settings()
