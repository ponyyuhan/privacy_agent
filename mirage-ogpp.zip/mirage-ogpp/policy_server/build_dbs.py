"""Build policy DB bitsets for the 2-server FSS-PIR guardrails demo.

We store 3 bitset databases (same on both servers):
- banned_tokens: hashed 4-gram tokens representing DLP patterns
- allow_recipients: hashed recipient identifiers allowed for egress
- allow_domains: hashed domain identifiers allowed for network access

The gateway queries these bitsets via FSS-PIR so that each policy server learns nothing about
the specific token/domain/recipient being checked.

NOTE: We use a *stable* SHA256-based hash -> index mapping (do NOT use Python's built-in hash()).
"""

import os
import hashlib
from pathlib import Path
import json

DOMAIN_SIZE = int(os.getenv("FSS_DOMAIN_SIZE", "4096"))  # must match gateway config
NBYTES = (DOMAIN_SIZE + 7) // 8

DATA_DIR = Path(__file__).resolve().parent / "data"
DATA_DIR.mkdir(exist_ok=True)

def set_bit(buf: bytearray, idx: int) -> None:
    byte_i = idx // 8
    bit_i = idx % 8
    buf[byte_i] |= (1 << bit_i)

def stable_idx(s: str) -> int:
    d = hashlib.sha256(s.encode("utf-8")).digest()
    x = int.from_bytes(d[:4], "little")
    return x % DOMAIN_SIZE

def add_fourgrams(buf: bytearray, pattern: str):
    p = pattern.replace("\n", " ")
    for i in range(0, max(0, len(p) - 3)):
        g = p[i:i+4]
        set_bit(buf, stable_idx(g))

def main():
    banned = bytearray(b"\x00" * NBYTES)
    allow_recipients = bytearray(b"\x00" * NBYTES)
    allow_domains = bytearray(b"\x00" * NBYTES)

    # --- DLP patterns (demo) ---
    patterns = [
        "AKIA",                        # AWS access key prefix
        "xoxb-",                       # Slack bot token prefix
        "OPENSSH PRIVATE KEY",         # private key marker
        "BEGIN PRIVATE KEY",           # generic key marker
    ]
    for pat in patterns:
        add_fourgrams(banned, pat)

    # --- Allowlisted recipients (demo) ---
    recipients = [
        "alice@example.com",
        "bob@example.com",
        # attacker is NOT allowlisted
    ]
    for r in recipients:
        set_bit(allow_recipients, stable_idx(r))

    # --- Allowlisted domains (demo) ---
    domains = [
        "example.com",
        "api.github.com",
    ]
    for d in domains:
        set_bit(allow_domains, stable_idx(d))

    (DATA_DIR / "banned_tokens.bitset").write_bytes(bytes(banned))
    (DATA_DIR / "allow_recipients.bitset").write_bytes(bytes(allow_recipients))
    (DATA_DIR / "allow_domains.bitset").write_bytes(bytes(allow_domains))

    meta = {
        "domain_size": DOMAIN_SIZE,
        "patterns": patterns,
        "allow_recipients": recipients,
        "allow_domains": domains,
        "hash": "sha256[:4] % domain_size",
        "tokenization": "char-4gram",
    }
    (DATA_DIR / "meta.json").write_text(json.dumps(meta, indent=2))
    print(f"[build_dbs] wrote bitsets to: {DATA_DIR}")
    print(json.dumps(meta, indent=2))

if __name__ == "__main__":
    main()
