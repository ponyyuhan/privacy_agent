import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from .config import settings
from .db import BitsetDB

app = FastAPI(title=f"PolicyServer{settings.server_id}", version="0.1")
db = BitsetDB(settings.data_dir)

class PirQuery(BaseModel):
    db: str
    key_share_b64: str

@app.on_event("startup")
def _startup():
    db.load()

@app.get("/health")
def health():
    return {"ok": True, "server_id": settings.server_id}

@app.post("/pir/query")
def pir_query(q: PirQuery):
    ans = db.query(q.db, q.key_share_b64)
    return {"ans_share": ans}

def main():
    uvicorn.run("policy_server.server:app", host="0.0.0.0", port=settings.port, reload=False)

if __name__ == "__main__":
    main()
