#!/usr/bin/env bash
set -euo pipefail

python policy_server/build_dbs.py

pick_port () {
  python - <<'PY'
import socket
s=socket.socket()
s.bind(("",0))
print(s.getsockname()[1])
s.close()
PY
}

wait_http_ok () {
  local url="$1"
  local tries="${2:-50}"
  python - <<PY
import time, sys
import requests
url="${url}"
tries=int("${tries}")
for i in range(tries):
    try:
        r = requests.get(url, timeout=0.5)
        if r.status_code == 200:
            sys.exit(0)
    except Exception:
        pass
    time.sleep(0.1)
sys.exit(1)
PY
}

# Choose free ports automatically (override by env if desired)
P0_PORT="${P0_PORT:-$(pick_port)}"
P1_PORT="${P1_PORT:-$(pick_port)}"
GW_PORT="${GW_PORT:-$(pick_port)}"

export POLICY0_URL="http://localhost:${P0_PORT}"
export POLICY1_URL="http://localhost:${P1_PORT}"
export GATEWAY_URL="http://localhost:${GW_PORT}"

echo "[run_all] POLICY0_URL=${POLICY0_URL}"
echo "[run_all] POLICY1_URL=${POLICY1_URL}"
echo "[run_all] GATEWAY_URL=${GATEWAY_URL}"

# Start policy servers
SERVER_ID=0 PORT="${P0_PORT}" python -m policy_server.server &
P0=$!
SERVER_ID=1 PORT="${P1_PORT}" python -m policy_server.server &
P1=$!

# Start gateway
PORT="${GW_PORT}" python -m gateway.app &
GW=$!

# Wait readiness
wait_http_ok "${POLICY0_URL}/health" 80
wait_http_ok "${POLICY1_URL}/health" 80
wait_http_ok "${GATEWAY_URL}/health" 80

echo "Running benign agent..."
python -m agent.nanoclaw_agent benign

echo "Running malicious agent..."
python -m agent.nanoclaw_agent malicious

kill $GW $P0 $P1 || true
