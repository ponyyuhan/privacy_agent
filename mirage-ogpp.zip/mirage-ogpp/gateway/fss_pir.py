import base64
import os
import secrets
from dataclasses import dataclass
from typing import Tuple
import requests

def _bitset_set_one(bitset: bytearray, idx: int) -> None:
    byte_i = idx // 8
    bit_i = idx % 8
    bitset[byte_i] ^= (1 << bit_i)

def gen_point_fss_keyshares(idx: int, domain_size: int) -> Tuple[bytes, bytes]:
    """Simple (inefficient) point-function secret sharing for a 1-hot selection vector.

    Returns (k0, k1) such that for any database D (bitset),
    <k0, D> XOR <k1, D> == D[idx]  (inner product over GF(2)).

    Key size is O(domain_size). Good enough for a demo.
    """
    if idx < 0 or idx >= domain_size:
        raise ValueError("idx out of range")
    nbytes = (domain_size + 7) // 8
    k0 = bytearray(secrets.token_bytes(nbytes))
    k1 = bytearray(k0)  # copy
    # flip one bit at idx so k0 XOR k1 becomes e_idx
    _bitset_set_one(k1, idx)
    return bytes(k0), bytes(k1)

@dataclass
class PirClient:
    policy0_url: str
    policy1_url: str
    domain_size: int

    def query_bit(self, db_name: str, idx: int, timeout_s: int = 10) -> int:
        k0, k1 = gen_point_fss_keyshares(idx, self.domain_size)
        payload0 = {"db": db_name, "key_share_b64": base64.b64encode(k0).decode("ascii")}
        payload1 = {"db": db_name, "key_share_b64": base64.b64encode(k1).decode("ascii")}

        r0 = requests.post(f"{self.policy0_url}/pir/query", json=payload0, timeout=timeout_s)
        r1 = requests.post(f"{self.policy1_url}/pir/query", json=payload1, timeout=timeout_s)
        r0.raise_for_status(); r1.raise_for_status()
        a0 = int(r0.json()["ans_share"]) & 1
        a1 = int(r1.json()["ans_share"]) & 1
        return a0 ^ a1
