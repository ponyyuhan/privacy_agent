import hashlib
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple

from .fss_pir import PirClient
from .handles import HandleStore

def stable_idx(s: str, domain_size: int) -> int:
    d = hashlib.sha256(s.encode("utf-8")).digest()
    x = int.from_bytes(d[:4], "little")
    return x % domain_size

def fourgram_indices(text: str, domain_size: int, max_tokens: int) -> List[int]:
    """Tokenize text into character 4-grams and hash each to an index in [0, domain_size).

    This is a demo-friendly surrogate for regex / multi-pattern matching.
    """
    s = text or ""
    s = s.replace("\n", " ")
    grams = []
    for i in range(0, max(0, len(s) - 3)):
        g = s[i:i+4]
        grams.append(g)
        if len(grams) >= max_tokens:
            break
    return [stable_idx(g, domain_size) for g in grams]

@dataclass
class GuardrailDecision:
    allow: bool
    reason_code: str
    details: str = ""

class ObliviousGuardrails:
    """Oblivious guardrails via 2-server FSS-PIR queries."""

    def __init__(self, pir: PirClient, handles: HandleStore, domain_size: int, max_tokens: int):
        self.pir = pir
        self.handles = handles
        self.domain_size = domain_size
        self.max_tokens = max_tokens

    def _contains_high_handle(self, artifacts: List[Dict[str, Any]], session: str) -> Tuple[bool, str]:
        for a in artifacts or []:
            hid = a.get("handle")
            if not hid:
                continue
            rec = self.handles.get(hid)
            if not rec:
                continue
            if rec.session != session:
                return True, "HANDLE_SESSION_MISMATCH"
            if rec.sensitivity.upper() == "HIGH":
                return True, "HIGH_HANDLE_BLOCKED"
        return False, ""

    def check_egress_message(self, *, recipient: str, text: str, artifacts: List[Dict[str, Any]], session: str) -> GuardrailDecision:
        # 1) hard IFC rule: HIGH handles cannot flow to egress
        bad, code = self._contains_high_handle(artifacts, session=session)
        if bad:
            return GuardrailDecision(False, code, "Sensitive handle cannot be externalized.")

        # 2) recipient allowlist (oblivious)
        ridx = stable_idx(recipient, self.domain_size)
        allowed = self.pir.query_bit("allow_recipients", ridx)
        if allowed != 1:
            return GuardrailDecision(False, "RECIPIENT_NOT_ALLOWED", "Recipient blocked by allowlist.")

        # 3) content DLP (oblivious)
        for idx in fourgram_indices(text, self.domain_size, self.max_tokens):
            hit = self.pir.query_bit("banned_tokens", idx)
            if hit == 1:
                return GuardrailDecision(False, "DLP_BLOCKED", "Outbound content matched a banned token (oblivious check).")

        return GuardrailDecision(True, "ALLOW", "OK")

    def check_network_domain(self, *, domain: str) -> GuardrailDecision:
        didx = stable_idx(domain, self.domain_size)
        allowed = self.pir.query_bit("allow_domains", didx)
        if allowed != 1:
            return GuardrailDecision(False, "DOMAIN_NOT_ALLOWED", "Domain blocked by allowlist.")
        return GuardrailDecision(True, "ALLOW", "OK")
