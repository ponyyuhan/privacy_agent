from typing import Dict, Any

from .handles import HandleStore
from .executors.fsexec import FSExec
from .executors.msgexec import MsgExec
from .executors.cryptoexec import CryptoExec
from .executors.netexec import NetExec
from .guardrails import ObliviousGuardrails

class IntentRouter:
    def __init__(self, handles: HandleStore, guardrails: ObliviousGuardrails):
        self.handles = handles
        self.guardrails = guardrails
        self.fs = FSExec(handles)
        self.msg = MsgExec(handles, guardrails)
        self.crypto = CryptoExec(handles)
        self.net = NetExec(handles, guardrails)

    def act(self, intent_id: str, inputs: Dict[str, Any], constraints: Dict[str, Any], caller: str, session: str) -> Dict[str, Any]:
        # Level 2: the agent cannot choose low-level tools; only intents exist.
        if intent_id == "ReadFile":
            return self.fs.read_file(inputs, session=session)
        if intent_id == "ReadSecret":
            return self.crypto.read_secret(inputs, session=session)
        if intent_id == "UseCredential":
            return self.crypto.use_credential(inputs, session=session)
        if intent_id == "SendMessage":
            return self.msg.send_message(inputs, session=session)
        if intent_id == "FetchResource":
            return self.net.fetch(inputs, session=session)
        if intent_id == "WriteWorkspaceFile":
            return self.fs.write_workspace_file(inputs, session=session)
        return {
            "status": "DENY",
            "summary": f"Unknown intent_id: {intent_id}",
            "data": {},
            "artifacts": [],
            "reason_code": "UNKNOWN_INTENT",
        }
