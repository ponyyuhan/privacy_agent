import json
from typing import Dict, Any
from ..handles import HandleStore

class CryptoExec:
    def __init__(self, handles: HandleStore):
        self.handles = handles

    def read_secret(self, inputs: Dict[str, Any], session: str) -> Dict[str, Any]:
        # In a real system this would use workload identity / attestation to mint short-lived capability tokens.
        name = str(inputs.get("name", ""))
        # Demo: mint a capability handle instead of returning secrets.
        rec = self.handles.mint(
            label="CAPABILITY",
            sensitivity="HIGH",
            value={"secret_name": name, "note": "demo secretless capability"},
            allowed_sinks=["UseCredential"],
            session=session,
            ttl_seconds=300,
        )
        return {
            "status": "OK",
            "summary": "Secretless capability minted (no plaintext secret returned).",
            "data": {"name": name},
            "artifacts": [{"handle": rec.handle, "label": rec.label, "sensitivity": rec.sensitivity}],
            "reason_code": "CAPABILITY_HANDLE",
        }

    def use_credential(self, inputs: Dict[str, Any], session: str) -> Dict[str, Any]:
        hid = str(inputs.get("handle", ""))
        op = str(inputs.get("op", "SIGN"))
        target = str(inputs.get("target", "generic"))

        rec = self.handles.get(hid)
        if not rec or rec.session != session:
            return {
                "status": "DENY",
                "summary": "Invalid or expired handle.",
                "data": {},
                "artifacts": [],
                "reason_code": "HANDLE_INVALID",
            }
        if "UseCredential" not in rec.allowed_sinks:
            return {
                "status": "DENY",
                "summary": "Handle cannot be used for this operation.",
                "data": {"label": rec.label},
                "artifacts": [],
                "reason_code": "HANDLE_SINK_BLOCKED",
            }

        # Demo: return a fake signature; do NOT reveal secrets.
        signature = f"sig({op}:{target}:{hid})"
        return {
            "status": "OK",
            "summary": "Credential used inside trusted executor (no secret disclosed).",
            "data": {"op": op, "target": target, "result": signature},
            "artifacts": [],
            "reason_code": "ALLOW",
        }
