from typing import Dict, Any
from ..handles import HandleStore
from ..guardrails import ObliviousGuardrails

class NetExec:
    def __init__(self, handles: HandleStore, guardrails: ObliviousGuardrails):
        self.handles = handles
        self.guardrails = guardrails

    def fetch(self, inputs: Dict[str, Any], session: str) -> Dict[str, Any]:
        # Demo: only allow fetching a resource_id that maps to a domain.
        resource_id = str(inputs.get("resource_id", "example"))
        domain = str(inputs.get("domain", "example.com"))

        dec = self.guardrails.check_network_domain(domain=domain)
        if not dec.allow:
            return {
                "status": "DENY",
                "summary": "Network fetch blocked by domain policy.",
                "data": {"domain": domain},
                "artifacts": [],
                "reason_code": dec.reason_code,
            }

        # Offline demo: return a canned response.
        return {
            "status": "OK",
            "summary": "Fetched resource (demo stub).",
            "data": {"resource_id": resource_id, "domain": domain, "content_preview": "<html>...</html>"},
            "artifacts": [],
            "reason_code": "ALLOW",
        }
