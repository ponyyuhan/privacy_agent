from typing import Dict, Any, List
from ..handles import HandleStore
from ..guardrails import ObliviousGuardrails

class MsgExec:
    def __init__(self, handles: HandleStore, guardrails: ObliviousGuardrails):
        self.handles = handles
        self.guardrails = guardrails

    def send_message(self, inputs: Dict[str, Any], session: str) -> Dict[str, Any]:
        channel = str(inputs.get("channel", "email"))
        recipient = str(inputs.get("recipient", ""))
        text = str(inputs.get("text", ""))
        artifacts = inputs.get("artifacts", []) or []

        dec = self.guardrails.check_egress_message(
            recipient=recipient,
            text=text,
            artifacts=artifacts,
            session=session,
        )
        if not dec.allow:
            return {
                "status": "DENY",
                "summary": "Message blocked by guardrails.",
                "data": {"channel": channel, "recipient": recipient},
                "artifacts": [],
                "reason_code": dec.reason_code,
            }

        # Demo: do not actually send; just acknowledge.
        return {
            "status": "OK",
            "summary": "Message allowed and sent (demo stub).",
            "data": {"channel": channel, "recipient": recipient, "sent_chars": len(text)},
            "artifacts": [],
            "reason_code": "ALLOW",
        }
