import time
import secrets
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional, List

@dataclass
class HandleRecord:
    handle: str
    label: str
    sensitivity: str  # LOW/MED/HIGH
    created_at: float
    ttl_seconds: int
    session: str
    value: Any  # stored only in gateway TCB (demo)
    allowed_sinks: List[str]

    def expired(self) -> bool:
        return (time.time() - self.created_at) > self.ttl_seconds

class HandleStore:
    def __init__(self):
        self._store: Dict[str, HandleRecord] = {}

    def mint(self, *, label: str, sensitivity: str, value: Any, allowed_sinks: List[str], session: str, ttl_seconds: int = 600) -> HandleRecord:
        hid = f"h_{secrets.token_urlsafe(16)}"
        rec = HandleRecord(
            handle=hid,
            label=label,
            sensitivity=sensitivity,
            created_at=time.time(),
            ttl_seconds=ttl_seconds,
            session=session,
            value=value,
            allowed_sinks=allowed_sinks,
        )
        self._store[hid] = rec
        return rec

    def get(self, hid: str) -> Optional[HandleRecord]:
        rec = self._store.get(hid)
        if not rec:
            return None
        if rec.expired():
            self._store.pop(hid, None)
            return None
        return rec

    def describe(self, hid: str) -> Optional[Dict[str, Any]]:
        rec = self.get(hid)
        if not rec:
            return None
        # do NOT reveal value
        return {
            "handle": rec.handle,
            "label": rec.label,
            "sensitivity": rec.sensitivity,
            "ttl_seconds": rec.ttl_seconds,
        }
